#!/usr/bin/env python
# coding: utf-8

# # What Drives International Sporting Success?  
# ### An Econometric Exploration of the Economic Determinants of International Sporting Success
# **ECONM0014: Econometrics with Python**   \
# **Student ID:** 2676835

# ## Introduction

# Why do some countries consistently dominate global sport while others struggle to make a name for themselves? This project investigates how economic strength relates to international sporting success. Bernard and Busse (2004) showed that GDP per capita, population and hosting are strong predictors of Olympic success. Building on their findings, I extend the analysis to the seven most recent Summer Olympic Games (2000–2024) and examine whether similar effects are found in international football using FIFA World Rankings. Finally, I use a Poisson model to predict medal counts for the Paris 2024 Olympics.
# 
# All data is collected externally via APIs or web scraping, combining economic indicators from the World Bank with Men's World Rankings from FIFA and Olympic medal tables from Wikipedia. I apply econometric tools covered in this unit, including OLS and count-data modelling, to assess how well simple economic variables explain and predict success on the global sporting stage.

# ## 0. Importing Libraries

# In[40]:


pip install linearmodels


# In[892]:


## Importing the relevant libraries
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns

import requests
from io import StringIO

from patsy import dmatrices
from linearmodels import PanelOLS
from scipy import stats
from linearmodels.panel import compare
import statsmodels.api as sm
from statsmodels.discrete.discrete_model import Poisson
from sklearn.metrics import mean_absolute_error as mae


# ## 1. Data Collection

# All data used in this project is obtained from external, publicly available APIs or web scraping, in line with the coursework requirements.
# 
# #### Economic Indicators (World Bank API)
# - GDP per capita (current USD)
# - Total population
# - Country, ISO-3 code, Year
# 
# Summer Olympic years 2000–2024

# #### Olympic Performance (Wikipedia Web Scraping)
# - Medal counts (Gold, Silver, Bronze, Total)
# - Medal table rank
# - Host-nation indicator
# - Country, Year
# 
# Scraped from the official medal table for each Summer Olympics (2000–2024)

# #### Football Performance (FIFA API)
# - FIFA World Ranking
# - FIFA Ranking Points
# - Confederation
# - Country, FIFA country code, Year
#  
# Rankings correspond to December of each Olympic year to maintain consistency with the economic data.

# #### Code Mapping (Wikipedia Web Scraping)
# A mapping table is scraped to align IOC, FIFA and ISO-3 country codes across datasets.

# ### 1.1 World Bank API

# #### 1.1.1 GDP per Capita

# In[866]:


## Extracting GDP per capita data
GDP = []

# Loop through Olympic years only
for i in range(2000, 2025, 4):
    # Request GDP per capita data for that year
    url = f"http://api.worldbank.org/v2/country/all/indicator/NY.GDP.PCAP.CD?format=json&date={i}&per_page=300"
    data = requests.get(url).json()
    
    # Extract and rename the relevant columns from the JSON response
    GDP_table = pd.json_normalize(data[1])
    GDP_table = GDP_table[['country.value', 'countryiso3code', 'value']]
    GDP_table = GDP_table.rename(columns={
        'country.value': 'Country',
        'countryiso3code': 'ISO',
        'value': 'GDP_per_capita'
    })

    # Add the corresponding Olympic year
    GDP_table['Year'] = i
    
    GDP.append(GDP_table)

# Concatenate all years into one dataframe
GDP_df = pd.concat(GDP, ignore_index=True)

GDP_df.head(2)


# #### 1.1.2 Population

# In[424]:


## Extracting Population data
pop = []

# Loop through Olympic years only
for i in range(2000, 2025, 4):
    # Request population data for that year
    url = f"http://api.worldbank.org/v2/country/all/indicator/SP.POP.TOTL?format=json&date={i}&per_page=300"
    data = requests.get(url).json()

    # Extract and rename the relevant columns from the JSON response
    pop_table = pd.json_normalize(data[1])
    pop_table = pop_table[['country.value', 'countryiso3code', 'value']]
    pop_table = pop_table.rename(columns={
        'country.value': 'Country',
        'countryiso3code': 'ISO',
        'value': 'Population'
    })

    pop_table['Year'] = i

    # Add the corresponding Olympic year
    pop.append(pop_table)

# Concatenate all years into one dataframe
pop_df = pd.concat(pop, ignore_index=True)

pop_df.head(2)


# ### 1.2 Olympic Performance

# In[890]:


## Extracting Olympic Medal Tables
medal_df = []

# Loop through the Summer Olympic years
for i in range(2000, 2025, 4):
    # Request Olympic medal tables for that year
    url = f'https://en.wikipedia.org/wiki/{i}_Summer_Olympics_medal_table'
    r = requests.get(url, headers={'User-Agent':'Mozilla/5.0'})
    
    # Extracting the table of interest
    tables = pd.read_html(StringIO(r.text))
    medal_table = tables[3].iloc[:-1].copy()

    # Adding the corresponding Olympic year
    medal_table['Year'] = i

    # Country names are cleaned and host dummy added
    medal_table['NOC'] = medal_table['NOC'].str.replace(r'[\‡\†]', '', regex=True)
    medal_table['Host'] = medal_table['NOC'].str.endswith('*').astype(int)
    medal_table['NOC'] = medal_table['NOC'].str.replace(r'[\*]', '', regex=True)
    
    medal_df.append(medal_table)

# Concatenate all years into one dataframe and rename country column to align with World Bank data
medal_df = pd.concat(medal_df, ignore_index=True)
medal_df.rename(columns={'NOC': 'Country'}, inplace=True)

medal_df.head(2)


# ### 1.3 FIFA Rankings

# In[868]:


# Creating a dictionary to map actual dates to FIFA's Date IDs (found manually by inspecting URL)
dates_dict = {
    "19/12/2024": "14597",
    "10/12/2020": "13127",
    "22/12/2016": "11678",
    "19/12/2012": "10214",
    "17/12/2008": "8751",
    "20/12/2004": "128",
    "20/12/2000": "80"
}


# In[869]:


## Extracting FIFA Rankings Data
fifa_df = []

# Loop over date IDs
for i in dates_dict.values():
    # Request FIFA rankings data for that Date ID
    url = f"https://inside.fifa.com/api/ranking-overview?locale=en&dateId=id{i}&rankingType=football"
    headers = {"User-Agent": "Mozilla/5.0"}
    data = requests.get(url, headers=headers).json()
    
    # Extract the relevant columns from the JSON response
    fifa_table = pd.json_normalize(data['rankings'])
    fifa_table = fifa_table[['rankingItem.name', 'rankingItem.countryCode', 'rankingItem.rank', 'rankingItem.totalPoints', 'tag.text', 'lastUpdateDate']]
    
    # Rename columns
    fifa_table = fifa_table.rename(columns={
        'rankingItem.name': 'Country',
        'rankingItem.rank': 'Ranking',
        'rankingItem.totalPoints': 'FIFA_ranking_points',
        'rankingItem.countryCode': 'countryCode',
        'tag.text': 'Confederation',
        'lastUpdateDate': 'Year'
    })
    
    # Convert the full date to year
    fifa_table['Year'] = pd.to_datetime(fifa_table['Year'], errors='coerce').dt.year
    
    fifa_df.append(fifa_table)

# Concatenate all years into one dataframe
fifa_df = pd.concat(fifa_df, ignore_index=True)

fifa_df.head(2)


# ### 1.4 IOC, FIFA & ISO codes

# In[870]:


## Extracting IOC, FIFA and ISO codes
url = 'https://simple.wikipedia.org/wiki/Comparison_of_IOC%2C_FIFA%2C_and_ISO_3166_country_codes'
r = requests.get(url, headers={'User-Agent':'Mozilla/5.0'})

# Extracting the relevant table
tables = pd.read_html(StringIO(r.text))
IOC_FIFA_ISO_table = tables[0].drop(columns='Flag')

IOC_FIFA_ISO_table.head(2)


# ## 2. Data Cleaning & Preparation

# Several cleaning and preparation steps were required before I could analyse the data. Firstly, the World Bank API includes regions in their *Country* column (e.g. "Africa Eastern and Southern"), which were removed. A small number of observations lacked crucial GDP per capita or population data and were dropped, as these variables are central to the analysis.
# 
# Two new variables were constructed as follows:
# - *Total_medal_share* = country medals divided by total medals available that year
# - *FIFA_reverse_rank* = max FIFA Ranking for that year + 1 - FIFA Ranking
# 
# Medal tables were merged with the IOC-FIFA-ISO mapping. The following had to be corrected manually:
# - FR Yugoslavia (2000) and Serbia & Montenegro (2004) were mapped to Serbia (successor state)
# - ROC was mapped to Russia (neutrality in 2020)
# - Non-country entities (e.g. Refugee Olympic Team) were dropped
# - Countries without economic data were dropped (North Korea and Chinese Taipei)
# 
# FIFA country codes were also mapped to ISO-3 codes. The following were corrected manually:
# - Serbia & Montenegro mapped to Serbia (successor team)
# - Netherlands Antilles mapped to Curaçao (successor team)
# - England was mapped to GBR to act as a proxy for the UK, while the other home nations were dropped, for consistency with World Bank data
# 
# All datasets were merged on ISO and Year. Countries without medals were assigned zeros in medal columns, and natural logarithms were taken of GDP per capita, population and FIFA Ranking Points. The remaining missing FIFA values are dealt with before the regression analysis. The final dataset is exported to a CSV file.

# ### 2.1 Economic Indicators

# #### Combining GDP per Capita and Population

# In[871]:


# Merging economic data and obtaining dataframe info
df = pd.merge(GDP_df, pop_df, how="inner", on=['Country', 'ISO', 'Year'])
df.info()


# In[872]:


# Dropping the nulls
df2 = df.dropna()


# #### Removing Regions

# In[873]:


# Creating a list containing all the regions (first 48 country names were found to be regions)
regions = df2['Country'].unique()[:48]

# Filtering out the regions to include only countries
df3 = df2[~df2['Country'].isin(regions)]
df3.head(2)


# ### 2.2 Olympics Data

# #### Adding Medal Share

# In[874]:


# Creating Total_medal_share variable as mentioned earlier
total_medals_per_year = medal_df.groupby('Year')['Total'].transform('sum')
medal_df['Total_medal_share'] = medal_df['Total'] / total_medals_per_year

medal_df.head(2)


# #### Adding ISO Codes

# In[875]:


# Mapping the ISO codes to Medal Tables
medal_df2 = pd.merge(medal_df, IOC_FIFA_ISO_table[['Country','ISO']], how='left', on='Country')
medal_df2.head(2)


# In[842]:


# Inspecting which countries did not map properly
medal_df2[medal_df2['ISO'].isnull()]['Country'].unique()


# In[843]:


# Manually map remaining countries
country_iso_map = {
    'China': 'CHN',
    'Great Britain': 'GBR',
    'South Korea': 'KOR',
    'Bahamas': 'BHS',
    'FR Yugoslavia': 'SRB', # mapped to Serbia
    'Chinese Taipei': 'TWN',
    'North Korea': 'PRK',
    'Ireland': 'IRL',
    'Macedonia': 'MKD',
    'Serbia and Montenegro': 'SRB', # mapped to Serbia
    'Hong Kong': 'HKG',
    'Samoa': 'WSM',
    'Ivory Coast': 'CIV',
    'Kosovo': 'XKX',
    'ROC': 'RUS', # mapped to Russia
    'North Macedonia': 'MKD',
    'Dominica': 'DMA',
}

# Mapping applied to medal_df2
missing_mask = medal_df2['ISO'].isna()
medal_df2.loc[missing_mask, 'ISO'] = (medal_df2.loc[missing_mask, 'Country'].map(country_iso_map))


# In[861]:


# Inspect which countries are in medal tables but not World Bank dataframe
medal_df2[~medal_df2['ISO'].isin(df4['ISO'].unique())]['Country'].unique()


# #### Combining with Economic Performance Dataset

# In[862]:


# Adding medal data to df3 and showing only medal columns have nulls
df4 = pd.merge(df3, medal_df2[medal_df2.columns.drop(['Country','Rank'])], how="left", on=['ISO', 'Year'])
df4.info()


# In[846]:


# Replacing nulls with zeros
df_olympics = df4.fillna(0)
df_olympics.head(2)


# ### 2.3 FIFA Ranking's Data

# #### Creating Reverse Rank

# In[847]:


# Creating reverse rank as defined earlier
fifa_df['FIFA_reverse_rank'] = fifa_df.groupby('Year')['Ranking'].transform('max') + 1 - fifa_df['Ranking']


# #### Adding ISO Codes

# In[848]:


# Mapping FIFA codes to ISO codes
fifa_df2 = pd.merge(fifa_df, IOC_FIFA_ISO_table[['FIFA', 'ISO']],
                    how="left",
                    left_on='countryCode',
                    right_on='FIFA')


# In[849]:


# Inspecting which countries did not map properly
fifa_df2[fifa_df2['ISO'].isnull()]['Country'].unique()


# In[850]:


# Manually map remaining countries
fifa_country_iso_map = {
    'Curacao': 'CUW', # two different spellings
    'Curaçao': 'CUW',
    'Netherlands Antilles': 'CUW', # mapped to Curaçao
    'Kosovo': 'XKX',
    'South Sudan': 'SSD',
    'Lebanon': 'LBN',
    'Serbia and Montenegro': 'SRB', # mapped to Serbia
    'Yugoslavia': 'SRB'
}

# Mapping applied to fifa_df2
missing_mask = fifa_df2['ISO'].isna()
fifa_df2.loc[missing_mask, 'ISO'] = fifa_df2.loc[missing_mask, 'Country'].map(fifa_country_iso_map)


# In[851]:


# Replace ISO of England with GBR and drop other home nations
fifa_df2.loc[fifa_df2['Country'] == 'England', 'ISO'] = 'GBR'
fifa_df2 = fifa_df2[~fifa_df2['Country'].isin(['Wales', 'Scotland', 'Northern Ireland'])]


# #### Combining with Olympics Dataset

# In[852]:


# Merging the Olympics and FIFA datasets
df5 = pd.merge(df_olympics, fifa_df2[['ISO', 'Year','Ranking', 'FIFA_reverse_rank','FIFA_ranking_points', 'Confederation']], how='left',on=['ISO','Year'])

# Defining the relevant columns
rel_cols = ['Country', 'ISO', 'Year',  # indicator columns
            'Total', 'Total_medal_share', 'Host',  # olympics columns
            'Ranking', 'FIFA_reverse_rank', 'FIFA_ranking_points', 'Confederation', # FIFA columns
            'GDP_per_capita', 'Population']  # economic performance columns

# Keeping only relevant columns
df_final = df5[rel_cols].copy()


# ### 2.4 Taking Logs

# In[853]:


# Taking logs of regressors
df_final['ln_GDP_per_capita'] = np.log(df_final['GDP_per_capita'])
df_final['ln_population'] = np.log(df_final['Population'])

# Taking logs of FIFA Ranking points
df_final['ln_FIFA_ranking_points'] = df_final['FIFA_ranking_points'].replace(0, np.nan)
df_final['ln_FIFA_ranking_points'] = np.log(df_final['ln_FIFA_ranking_points'])

df_final.head(2)


# ### 2.5 Exporting the Dataset

# In[879]:


# Code to export dataset to CSV (currently commented out)

# df_final.to_csv("final_merged_olympics_fifa_data.csv", index=False)


# In[880]:


# Import dataset
df_final = pd.read_csv("final_merged_olympics_fifa_data.csv")
df_final.head(2)


# The final cleaned dataset contains the following variables:
# 
# | Variable | Description |
# |---------|-------------|
# | Country | Country name |
# | ISO | ISO-3 country code |
# | Year | Summer Olympic year |
# | Total | Total number of medals won at the Olympics |
# | Total_medal_share | Share of all medals won |
# | Host | Host Nation indicator |
# | Ranking | FIFA Men’s World Ranking (December) |
# | FIFA_reverse_rank | Reverse of FIFA Men's World Ranking |
# | FIFA_ranking_points | Official FIFA Ranking points |
# | Confederation | Continental football confederation |
# | GDP_per_capita | GDP per capita (current USD) |
# | Population | National population |
# | ln_GDP_per_capita | Log of GDP per capita |
# | ln_population | Log of population |
# | ln_FIFA_ranking_points | Log of FIFA Ranking points |

# ## 3. Research Questions

# This analysis is structured around three core questions:
# 
# #### 1. How do economic factors influence Olympic success?
# - How unequal are Olympic medals distributed across countries?
# - Does GDP per capita help explain why some countries win more medals, after controlling for population size?
# - Is there a measurable home advantage in the Olympics?
# 
# #### 2. Do similar economic relationships exist in international football?
# - Do wealthier nations achieve higher FIFA Ranking Points, controlling for population?
# - Do some confederations systematically outperform others?
# - Which countries over- or under-perform relative to model predictions?
# 
# #### 3. Can we use more advanced econometric tools to model medal counts?
# - Is a Poisson regression model suitable for modelling medal counts?
# - How sensitive are medal totals to changes in GDP per capita?
# - How well can a model based only on GDP per capita, population and hosting predict Paris 2024 results?
# - Which nations exceed or fall short of their predicted success?

# ## 4. Exploratory Data Analysis (EDA)

# In this section, I explore the main characteristics of the dataset using summary statistics and visualisations.

# ### 4.1 Economic Indicators

# #### Descriptive Statistics & Distributions

# In[856]:


# Defining and describing the economic indicator columns
ei_cols = ['GDP_per_capita', 'Population', 'ln_GDP_per_capita', 'ln_population']
df_final[ei_cols].describe()


# In[857]:


# Plot histograms to visualise the distributions of economic indicator variables
variables = [
    ('GDP_per_capita', 'ln_GDP_per_capita'),
    ('Population', 'ln_population')
]

# Loop over raw and logged variables to create four subplots
for raw, log in variables:
    plt.figure(figsize=(12,5))

    # Subplot for raw distribution
    plt.subplot(1,2,1)
    sns.histplot(df_final[raw], bins=50, color='skyblue')
    plt.title(f'{reg} Distribution (raw)')

    # Subplot for log-transformed distribution
    plt.subplot(1,2,2)
    sns.histplot(df_final[log], bins=50, color='salmon')
    plt.title(f'{log} Distribution (log-transformed)')

    plt.tight_layout()
    plt.show()


# GDP per capita and population vary widely across countries and are strongly right-skewed. Applying logs makes distribution look much more symmetrical and normal.

# ### 4.2 Olympics Performance

# #### Descriptive Statistics & Medal Distributions

# In[540]:


# Defining and describing the olympics-related columns
olympic_cols = ['Total', 'Total_medal_share', 'Host']
df_final[olympic_cols].describe()


# In[628]:


# Histogram showing distribution of medals
sns.histplot(df_final['Total'], bins=50, color='skyblue')
plt.xlabel('Total Medals')
plt.title('Distribution of Total Olympic Medals')
plt.tight_layout()
plt.show()


# #### Temporal Trends

# In[546]:


## Plots showing sum of medals at each olympics and average medal share

# Find totals and averages grouped by year
medals_sum = df_final.groupby('Year')['Total'].sum()
medal_share_avg = df_final.groupby('Year')['Total_medal_share'].mean() * 100

plt.figure(figsize=(12,5))

# Subplot for sum of medals
plt.subplot(1,2,1)
sns.lineplot(x=medals_sum.index, y=medals_sum.values, marker='o', color='skyblue')
plt.xticks(medals_sum.index)
plt.xlabel("Olympic Year")
plt.ylabel("Medals")
plt.title("Sum of Olympic Medals Available")

# Subplot for average of medal shares
plt.subplot(1,2,2)
sns.lineplot(x=medal_share_avg.index, y=medal_share_avg.values, marker='o', color='salmon')
plt.xticks(medal_share_avg.index)
plt.xlabel("Olympic Year")
plt.ylabel("Average Medal Share (%)")
plt.title("Average Country Medal Share Across Olympic Games")
plt.ylim(0,1)

plt.tight_layout()
plt.show()


# #### Scatterplots

# In[629]:


# Scatterplots of Medal Shares vs log(GDP per capita) and log(Population)
plt.figure(figsize=(12,5))

# Subplot for GDP per capita
plt.subplot(1,2,1)
sns.scatterplot(x='ln_GDP_per_capita', y='Total_medal_share', data=df_final, s=20)
plt.title('Medal Share vs GDP per Capita')
plt.xlabel('ln(GDP per Capita)')
plt.ylabel('Total Medal Share')

# Subplot for Population
plt.subplot(1,2,2)
sns.scatterplot(x='ln_population', y='Total_medal_share', data=df_final, s=20)
plt.title('Medal Share vs Population')
plt.xlabel('ln(Population)')
plt.ylabel('Total Medal Share')

plt.tight_layout()
plt.show()


# #### Host Impact

# In[883]:


## Plot medal shares over time for host nations, indicating which year they hosted

# Filter for only countries that have hosted
hosts = df_final[df_final['Host']==1]['Country'].unique()
hosts_df = df_final[df_final['Country'].isin(hosts)].copy()

plt.figure(figsize=(12,7))

# Plot medal share over time for all host countries
sns.lineplot(
    x='Year',
    y='Total_medal_share',
    data=hosts_df,
    hue='Country',
)

# Indicator for when a country hosted plotted on top of the line graph
host_only = hosts_df[hosts_df['Host'] == 1]
plt.scatter(
    host_only['Year'], host_only['Total_medal_share'],
    s=80, color='red', edgecolor='black', zorder=5, label='Host Year'
)

# Label each host year with country ISO code
for _, row in host_only.iterrows():
    plt.text(row['Year']+0.1, row['Total_medal_share']+0.002,
             row['ISO'], fontsize=8)

plt.title("Medal Shares Over Time for Host Nations")
plt.xticks(hosts_df['Year'])
plt.xlabel("Olympic Year")
plt.ylabel("Medal Share")
plt.legend(title="Host Nations")
plt.grid(True, linestyle='--', alpha=0.4)
plt.tight_layout()
plt.show()


# #### Comments

# Olympic medals are unevenly distributed. Most countries win no medals, while a small number dominate the medal tables. Medal counts vary across Olympics, but medal shares remain fairly stable. Scatter plots show a positive relationship between medal shares and both economic variables. Hosting seems to increase a given country's medal share, especially for China (2008) and France (2024), indicating a home-advantage effect.

# ### 4.3 FIFA Performance

# #### Temporal Trends

# In[209]:


## Plot average FIFA ranking points over time

# Compute averages of each year
points_avg = df_final.groupby('Year')['FIFA_ranking_points'].mean()

# Plot averages over time
sns.lineplot(x=points_avg.index, y=points_avg.values, marker='o', color='salmon')
plt.xticks(points_avg.index)
plt.xlabel("Year")
plt.ylabel("FIFA Ranking Points")
plt.title("Average FIFA Ranking Points Over Time")
plt.tight_layout()
plt.show()


# For FIFA Ranking Points, a major shift occurred after 2018, when FIFA introduced a new points system (FIFA, 2018). The average point level increases sharply, making the two periods not directly comparable. I will therefore split the data and run two separate models.

# #### Descriptive Statistics & Distributions

# In[618]:


# Split the FIFA data into pre- and post-2018 as mentioned
df_pre2018 = df_final[df_final['Year'] < 2018].copy()
df_post2018 = df_final[df_final['Year'] > 2018].copy()


# In[887]:


# Defining and describing FIFA columns for both periods

fifa_cols = ['FIFA_ranking_points', 'ln_FIFA_ranking_points', 'Confederation']

pre_stats = df_pre2018[fifa_cols].describe()
post_stats = df_post2018[fifa_cols].describe()

combined_stats = pd.concat({"Pre-2018": pre_stats, "Post-2018": post_stats},axis=1)
combined_stats


# In[631]:


# Histogram for log of FIFA ranking points pre & post 2018
plt.figure(figsize=(12,5))

# Subplot for pre-2018
plt.subplot(1,2,1)
sns.histplot(df_pre2018['ln_FIFA_ranking_points'], bins=50, color='skyblue')
plt.title('Distribution of log of FIFA Ranking Points Pre-2018')
plt.xlabel('FIFA Ranking Points')
plt.ylabel('Count')

# Subplot for post-2018
plt.subplot(1,2,2)
sns.histplot(df_post2018['ln_FIFA_ranking_points'], bins=50, color='salmon')
plt.title('Distribution of log of FIFA Ranking Points Post-2018')
plt.xlabel('ln(FIFA Ranking Points)')
plt.ylabel('Count')

plt.tight_layout()
plt.show()


# #### Scatterplots

# In[625]:


# Scatterplots for FIFA Ranking Points vs GDP per capita and Population
plt.figure(figsize=(12,5))

# Subplot for FIFA points vs GDP
plt.subplot(1,2,1)
sns.scatterplot(x='ln_GDP_per_capita', y='ln_FIFA_ranking_points', hue='Year', data=df_final, palette='tab10', s=20)
plt.title('Log of FIFA Ranking Points vs Log of GDP per Capita')
plt.xlabel('ln(GDP per Capita)')
plt.ylabel('FIFA Ranking Points')
plt.legend(title='Year')

# Subplot for FIFA points vs population
plt.subplot(1,2,2)
sns.scatterplot(x='ln_population', y='ln_FIFA_ranking_points', hue='Year', data=df_final, palette='tab10', s=20)
plt.title('Log of FIFA Ranking Points vs Log of Population')
plt.xlabel('ln(Population)')
plt.ylabel('FIFA Ranking Points')
plt.legend(title='Year')

plt.tight_layout()
plt.show()


# #### Confederation Impact

# ![Figure 1: FIFA World Map](World_Map_FIFA.png)
# *Figure 1: FIFA confederations by country (source: [Wikipedia](https://en.wikipedia.org/wiki/File%3AWorld_Map_FIFA.svg))*

# In[256]:


# Setting colour palette to be similar to Figure 1
confed_palette = {
    'UEFA': 'royalblue',
    'CONMEBOL': 'darkseagreen',
    'CAF': 'orange',
    'CONCACAF': 'crimson',
    'AFC': 'pink',
    'OFC': 'yellow'
}


# In[612]:


## Boxplots to compare confederations
# Sort confederations by average points
order = df_final.groupby('Confederation')['FIFA_ranking_points'].median().sort_values(ascending=False).index

plt.figure(figsize=(10,6))

# Create boxplot for distribution of boxplots by confederatin
sns.boxplot(
    x='Confederation',
    y='FIFA_reverse_rank',
    hue='Confederation',
    data=df_final,
    order=order,
    palette=confed_palette
)

plt.title('Distribution of FIFA Rankings by Confederation')
plt.xlabel('')
plt.ylabel('FIFA Reverse Ranking')
plt.grid(axis='y', linestyle='--', alpha=0.3)
plt.legend([],[], frameon=False)
plt.show()


# #### Comments
# 
# Log-transforming points reduces skewness in both periods. Similar to the Olympics, there is a positive relationship between FIFA Ranking Points and economic variables. UEFA and CONMEBOL nations typically rank higher than those of other confederations, supporting the inclusion of confederation dummies later in the regression analysis.

# ## 5. Econometric Analysis

# ### 5.1 Olympics Performance Regression

# We run the following OLS Regression Model for predicting medal shares:
# 
# $ MedalShare_{it} = \beta_0 + \beta_1 log(GDP per capita)_{it} + \beta_2 log(Population)_{it} + \beta_3 Host_{it} + u_{it}$

# In[858]:


## Run the OLS regression and print the results

df_final = df_final.set_index(['Country', 'Year'])

y, X = dmatrices('Total_medal_share ~ ln_GDP_per_capita + ln_population + Host', data=df_final, return_type='dataframe')

model_olympics_OLS = PanelOLS(y, X)
results_olympics_OLS = model_olympics_OLS.fit(cov_type='clustered', cluster_entity=True)
print(results_olympics_OLS)


# To test whether GDP per capita is significant in explaining Medal Shares, we can run the following Hypothesis Test:
# 
# $ H_0: \beta_1 = 0 $ \
# $ H_A: \beta_1 \neq 0 $
# 
# The coefficient of log GDP per capita (0.0032) implies that a 1% increase in GDP per capita is associated with approximately a 0.32 percentage point increase in medal shares. We can say with 95% confidence that this value lies between 0.17 and 0.46. The t-statistic of around 4.38 is greater than 2, so we can reject the null hypothesis at the 5% level, meaning there is a statistically significant relationship between GDP per capita and Medal Shares. Host status is also strongly significant, with hosts gaining around 3.82 additional percentage points of medal share on average. All coefficients align with prior expectations and have extremely low p-values.
# 
# Unfortunately, these relationships cannot be interpreted as causal, since the model likely suffers from some endogeneity. Important determinants of sporting success, such as government funding and sporting culture, are omitted, so the effect of GDP per capita may be biased upwards if richer nations invest more in sport. OLS is also limited when modelling shares bounded between 0 and 1 since it doesn't respect the lower bound, so predictions could become negative. Finally, the relatively low R-squared (0.33) further suggests that much variation remains unexplained.

# ### 5.2 FIFA Performance Regression

# We estimate the following OLS regression model for both pre- and post-2018:
# 
# $ log(FIFA Ranking Points)_{it} = \beta_0 + \beta_1 log(GDP per capita)_{it} + \beta_2 log(Population)_{it} + \gamma C_i + u_{it} $
# 
# where $C_i$ is equal to a vector of confederation dummies.

# In[640]:


# Drop the nulls and set index
df_pre2018 = df_pre2018.dropna()
df_post2018 = df_post2018.dropna()

df_pre2018 = df_pre2018.set_index(['Country', 'Year'])
df_post2018 = df_post2018.set_index(['Country', 'Year'])


# In[694]:


# Run the OLS regression for pre-2018
y, X = dmatrices('ln_FIFA_ranking_points ~ ln_GDP_per_capita + ln_population + C(Confederation)', data=df_pre2018, return_type='dataframe')

model_fifa_pre2018_OLS = PanelOLS(y, X)
results_fifa_pre2018_OLS = model_fifa_pre2018_OLS.fit(cov_type='clustered', cluster_entity=True)


# In[695]:


# Run the OLS regression for post-2018
y, X = dmatrices('ln_FIFA_ranking_points ~ ln_GDP_per_capita + ln_population + C(Confederation)', data=df_post2018, return_type='dataframe')

model_fifa_post2018_OLS = PanelOLS(y, X)
results_fifa_post2018_OLS = model_fifa_post2018_OLS.fit(cov_type='clustered', cluster_entity=True)


# In[699]:


# Print a comparison table to compare the results of pre- and post-2018 regressions
print(compare({"Pre-2018 OLS": results_fifa_pre2018_OLS, "Post-2018 OLS": results_fifa_post2018_OLS}))


# The results support splitting the sample around FIFA’s 2018 ranking system change. In both models, GDP per capita has a positive and statistically significant effect on FIFA Ranking Points, with t-statistics above 2. Before 2018, a 1% increase in GDP per capita is associated with roughly a 0.13% increase in FIFA Ranking Points, while after 2018 the marginal effect is smaller (about 0.05%). This difference mainly reflects the higher scale of points in the newer system.
# 
# Confederation membership also plays a significant role. For example, pre-2018, the UEFA coefficient is 0.9876. The marginal effect, $e^{0.9876} - 1 \approx 1.68%$, indicates that on average, UEFA nations have around 168% higher FIFA ranking points than AFC nations (baseline), after controlling for GDP per capita and population. The higher R-squared post-2018 suggests the model fits the updated ranking system better.
# 
# However, as with the Olympic model, we cannot infer causality from these associations. The model again likely suffers from endogeneity, as key variables such as sports investment or domestic league strength are omitted, likely creating upward bias. Furthermore, such variables likely exhibit simultaneity with sporting performance - football success may lead to greater investment.

# In[888]:


## Create a plot to show biggest over- and under-performers post-2018
# Obtain residuals from the post-2018 model
df_post2018["residuals"] = results_fifa_post2018_OLS.resids

# Compute the average across years for each country
country_performance = df_post2018.groupby("Country")["residuals"].mean().sort_values(ascending=False).reset_index()

# Create a new column equal to the negative of the residual (easier for visualisation)
country_performance['negative_residuals'] = - country_performance['residuals']

# Top 10 over- and under-performin nations
top_over = country_performance.head(10)
top_under = country_performance.tail(10)

# Create a barplot to visualise
plt.figure(figsize=(12, 6))
# Subplot for top 10 over-performers
plt.subplot(1,2,1)
sns.barplot(y="Country", x="residuals", data=top_over, hue='Country')
plt.title("Top 10 FIFA Over-performers")
plt.xlabel("Average Positive Residual")
plt.ylabel("")
plt.grid(axis="x", alpha=0.3)

# Subplot for top 10 under-performers
plt.subplot(1,2,2)
sns.barplot(y="Country", x="negative_residuals", data=top_under.sort_values(by='residuals'), hue='Country')
plt.title("Top 10 FIFA Under-performers")
plt.xlabel("Average Negative Residual")
plt.ylabel("")
plt.grid(axis="x", alpha=0.3)
plt.xticks(rotation=45, ha='right')

plt.tight_layout()
plt.show()


# The bar charts show the biggest over- and under-performers relative to the model. Pakistan is the largest under-performer, likely due to its huge population but limited football success. On the other hand, Curaçao is the biggest over-performer. They recently became the smallest nation ever to qualify for the FIFA World Cup, helped by many players being born and trained in the Netherlands (Cryer, 2025). The current model cannot capture these dual-nationality pathways, which could be an interesting variable to explore in future work.

# ### 5.3 Advanced Econometrics Techniques

# #### 5.3.1 Poisson Regression

# In[360]:


# Run Poisson regression and print results table
y, X = dmatrices('Total ~ ln_GDP_per_capita + ln_population + Host', data=df_final, return_type='dataframe')

model_poisson = Poisson(y, X)
est_poisson = model_poisson.fit()
print(est_poisson.summary())


# In[361]:


# Calculate marginal effects at the mean and print results
margeff_poisson = est_poisson.get_margeff()
print(margeff_poisson.summary())


# The Poisson regression is a much more appropriate model for estimating medal counts, and it seems to be performing well, judging by the pseudo R-squared score of 0.65. Looking at the marginal effects, we can say that a 1% increase in GDP per capita is associated with an increase of approximately 3.1 medals for a country with average statistics. The effect is similar for population. The coefficients all align with prior expectations, suggesting economic size and hosting have a positive influence on medal counts, with all variables being strongly significant.

# #### 5.3.2 Poisson Prediction

# Similar to Bernard and Busse (2004), who use their model to predict the Sydney 2000 Olympic Games, I use a Poisson model trained on the data from Sydney 2000 to Tokyo 2020 to predict the medal table at the Paris 2024 Olympics. Medal counts are discrete values, so predicted values are converted to integers. Russia is excluded because they were banned from participating in the 2024 Summer Olympics (International Olympic Committee, 2023).

# In[792]:


# Create dataframes for prediction
df_prediction = df_final.reset_index()

# Define dataframe for model to be trained on and prediction set
df_model = df_prediction[df_prediction['Year']!=2024].copy()
df_paris = df_prediction[df_prediction['Year']==2024].copy().set_index(['ISO'])

# Dropping Russia due to ban
df_paris = df_paris.drop('RUS')

y_model, X_model = dmatrices('Total ~ ln_GDP_per_capita + ln_population + Host', data=df_model, return_type='dataframe')
y_paris, X_paris = dmatrices('Total ~ ln_GDP_per_capita + ln_population + Host', data=df_paris, return_type='dataframe')


# In[793]:


# Run the Poisson regression on Olympics data from 2000 to 2020
model_poisson2 = Poisson(y_model, X_model)
est_poisson2 = model_poisson2.fit()

y_pred = est_poisson2.predict(X_paris)


# In[794]:


## Plot actual vs predicted medals
# Convert predictions to integers
y_pred_int = y_pred.astype(int)

# Scatterplot of actual vs predicted
plt.figure(figsize=(12, 10))
plt.scatter(y_pred_int, y_paris, color='black', label='Countries', s=10)

# Label each country with ISO code
for country in y_paris.index:
    x = y_pred_int.loc[country].item()
    y = y_paris.loc[country].item()
    plt.text(x + 1, y - 1, country, fontsize=8, color='black')

# Plot 45 degree line to indicate perfect prediction
plt.plot([0, 200], [0, 200], 'r--', linewidth=2, label='Perfect prediction')

plt.xlim(0, 200)
plt.ylim(0, 200)
plt.xlabel('Predicted Medals')
plt.ylabel('Actual Medals')
plt.title('Actual vs Predicted Olympic Medals for 2024')
plt.legend()
plt.grid(True)
plt.show()


# In[807]:


## Zoom in on observations clustered to zero

# Filter for nations that won less than 50 medals
y_paris2 = y_paris[y_paris['Total']<=50]
y_pred2 = y_pred_int.loc[y_paris2.index]

# Second scatterplot
plt.figure(figsize=(12, 10))
plt.scatter(y_pred2, y_paris2, color='black', label='Countries', s=10)

# Label each country with ISO code
for country in y_paris2.index:
    x = y_pred2.loc[country].item()
    y = y_paris2.loc[country].item()
    plt.text(x + 0.5, y, country, fontsize=8, color='black')

# Plot 45 degree line again
plt.plot([0, 50], [0, 50], 'r--', linewidth=2, label='Perfect prediction')

plt.xlim(0, 50)
plt.ylim(0, 50)
plt.xlabel('Predicted Medals')
plt.ylabel('Actual Medals')
plt.title('Actual vs Predicted Olympic Medals for 2024')
plt.legend()
plt.grid(True)
plt.show()


# In[802]:


# Calculate and print the mean absolute error of the model
model_error = mae(y_paris, pd.DataFrame(y_pred_int))
print("Mean Absolute Error:", np.round(model_error,2))


# The first scatterplot shows the full prediction, while the second offers a slightly zoomed-in perspective, providing a clearer picture of medal counts clustered around zero. Overall, most countries seem to lie reasonably close to the 45-degree line, with some predictions even matching perfectly (France as the hosts, Sweden and Kazakhstan). Australia and Great Britain appear notably above the line, indicating substantially better-than-predicted medal returns. Despite having the world's largest population, India's Olympic success remains limited. Another clear under-performer was Saudi Arabia, who were predicted to win almost 20 medals (likely due to their high GDP per capita) but did not win a single medal. Furthermore, the mean absolute error is 3.63, which is an improvement on the 4.3 medals reported by Bernard and Busse (2004) when predicting the Sydney 2000 Olympics. While the Poisson model performs well in prediction, predictive success does not imply causality, as the model still suffers from endogeneity stemming from omitted variables.

# ## 6. Conclusion

# This analysis shows that economic strength plays a key role in international sporting success. Wealthier nations tend to perform better at both the Olympics and in global football rankings, after controlling for population. Hosting the Olympics also appears to boost medal performance, while in football, confederation membership matters as Europe and South America consistently outperform the rest of the world.
# 
# However, causal conclusions cannot be drawn from these results. The models likely suffer from endogeneity arising from omitted variables (such as sports investment, cultural priorities or domestic league strength), some of which may also have some simultaneity with sporting success. This explains why countries such as Curaçao in football or India at the Olympics perform very differently from what the models predict.
# 
# Future work could aim to identify a causal relationship by expanding the scope to many more Olympics or by using full annual FIFA rankings, enabling panel-data methods such as country fixed effects to control for unobservable national characteristics (such as cultural priorities). Including additional regressors, such as sports investment, could reduce omitted variable bias; however, because success may itself influence investment, this variable is likely endogenous due to reverse causality. In that case, instrumental variables could help address this simultaneity, although finding a valid instrument may be challenging.

# ## References

# 2000 Summer Olympics medal table. (2025) *Wikipedia*. Available at: https://en.wikipedia.org/wiki/2000_Summer_Olympics_medal_table (Accessed: November 2025)
# 
# 2004 Summer Olympics medal table. (2025) *Wikipedia*. Available at: https://en.wikipedia.org/wiki/2004_Summer_Olympics_medal_table (Accessed: November 2025)
# 
# 2008 Summer Olympics medal table. (2025) *Wikipedia*. Available at: https://en.wikipedia.org/wiki/2008_Summer_Olympics_medal_table (Accessed: November 2025)
# 
# 2012 Summer Olympics medal table. (2025) *Wikipedia*. Available at: https://en.wikipedia.org/wiki/2012_Summer_Olympics_medal_table (Accessed: November 2025)
# 
# 2016 Summer Olympics medal table. (2025) *Wikipedia*. Available at: https://en.wikipedia.org/wiki/2016_Summer_Olympics_medal_table (Accessed: November 2025)
# 
# 2020 Summer Olympics medal table. (2025) *Wikipedia*. Available at: https://en.wikipedia.org/wiki/2020_Summer_Olympics_medal_table (Accessed: November 2025)
# 
# 2024 Summer Olympics medal table. (2025) *Wikipedia*. Available at: https://en.wikipedia.org/wiki/2024_Summer_Olympics_medal_table (Accessed: November 2025)
# 
# Bernard, A.B. and Busse, M.R. (2004) ‘Who wins the Olympic Games: Economic resources and medal totals’, *Review of Economics and Statistics*, 86(1), pp. 413–417. Available at: https://www.researchgate.net/publication/24095908_Who_Wins_the_Olympic_Games_Economic_Resources_and_Medal_Totals
# 
# Cryer, A. (2025) ‘Curacao become smallest nation to qualify for World Cup’, *BBC Sport*, 19 November. Available at: https://www.bbc.co.uk/sport/football/articles/c14p3dmdld1o (Accessed: November 2025)
# 
# FIFA (2018) *Revision of the FIFA / Coca-Cola World Ranking Overview*. Available at: https://digitalhub.fifa.com/m/f99da4f73212220/original/edbm045h0udbwkqew35a-pdf.pdf (Accessed: November 2025)
# 
# FIFA (2025) *FIFA Men’s World Ranking API*. Available at: https://www.fifa.com (Accessed: November 2025)
# 
# International Olympic Committee (2023) *IOC Executive Board suspends Russian Olympic Committee with immediate effect*, Olympics.com. Available at: https://www.olympics.com/ioc/news/ioc-executive-board-suspends-russian-olympic-committee-with-immediate-effect (Accessed: November 2025)
# 
# Wikipedia Contributors (2023) *File:World Map FIFA.svg*. Wikipedia. Available at: https://en.wikipedia.org/wiki/File%3AWorld_Map_FIFA.svg (Accessed: November 2025)
# 
# World Bank (2024) *World Development Indicators [API]*. Available at: https://data.worldbank.org (Accessed: November 2025)
